from setuptools import setup, find_packages

setup(
    name='criatela',
    version='1.0.0',
    description='cria telas em html',
    author='Adelson',
    author_email = 'testeaaa@a.com',
    packages=find_packages(),
    install_requires=[
            ],
)
